<template>
  <AppLayout />
</template>

<script setup lang="ts">
import AppLayout from './components/Layout/AppLayout.vue'
</script>
